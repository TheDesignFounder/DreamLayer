# DreamLayer Inference Report

This bundle contains:
- Inference results (results.csv)
- Configuration used (config.json)
- Grid images with seeds and parameters
